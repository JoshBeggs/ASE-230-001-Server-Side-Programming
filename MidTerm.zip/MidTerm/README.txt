This project is in a Terrible state.

I would like to speak to you about ways that, if possible, could bring my grade back up to a passing state.  I will be sending you an email tomorrow (17OCT2022) to set up a time to discuss this.