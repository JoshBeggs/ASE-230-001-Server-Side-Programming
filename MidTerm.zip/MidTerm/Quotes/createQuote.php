<?php

if(count($_POST)>0){

    $error='';
    //Make sure the quote is not already in the file
    if(file_exists('../Data/quotes.csv')){
        $fh=fopen('../Data/quotes.csv','r');
        while($line=fgets($fh)) {
            if($_POST['quote']==trim($line)) {
                //found the quote already
                $error='This quote already exists';   
            };
        }
    }
    fclose($fh);

    if(strlen($error)>0) echo $error;
    else{
        //add the quote to the csv file
        $fh=fopen('../Data/quotes.csv','a');
        //open author.csv
        $fh2=fopen('../Data/authors.csv','a');


        fputs($fh,$_POST['quote'].PHP_EOL);
        fclose($fh);
        echo 'Thanks for adding '.$_POST['quote'].' to our wabsite!';
    }

    //ADD THE QUOTE TO THE CSV FILE
}
?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Create a Quote</title>
</head>
    
<form method="POST">
    Select the author's name:<br/>
    <input type="list" name="name" /><br />
        <datalist id="name">
        <?php
            $fhAuthor=fopen('../Data/authors.csv','r');
            $index=0;
            
            while($line=fgets($fhAuthor)) {
                if(strlen(trim($line))>0) echo '<option value="'.trim($line).'">'; 

                $index++;
            }
            fclose($fhAuthor);
        ?>
    Enter the quote:<br/>
    <input type="text" name="quote" /><br />
    <button type="submit">Add quote</button>
</form>