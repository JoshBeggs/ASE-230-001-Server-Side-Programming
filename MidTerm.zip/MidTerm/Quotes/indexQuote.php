<?php
$fhAuthor=fopen('../Data/authors.csv','r');
$fhQuote=fopen('../Data/quotes.csv','r');
$index=0;

while($line=fgets($fhAuthor)) {
    if(strlen(trim($line))>0) {
        echo '<h1><a href="detail.php?index='.$index.'">'.trim($line).'</a> (<a href="modify.php?index='.$index.'">modify</a>) (<a href="delete.php?index='.$index.'">delete</a>)</h1><br/>';
        while($lineQuote=fgets($fhQuote)) {
            if(($lineQuote[0])== $index + 1) {
                echo '<p><a href="detailQuote.php?index='.$index.'">'.trim($lineQuote).'</a> (<a href="modifyQuote.php?index='.$index.'">modify the quote</a>) (<a href="deleteQuote.php?index='.$index.'">delete the quote</a>)</p>';;
            }
        }
    }
    $index++;
}
fclose($fhAuthor);
fclose($fhQuote);
?>