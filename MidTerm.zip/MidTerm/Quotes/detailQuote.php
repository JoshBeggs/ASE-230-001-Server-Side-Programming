<?php

$fh=fopen('../Data/quotes.csv','r');
$line_counter=0;

while($line=fgets($fh)){
    if($line > 0) {
        //display the quote
        echo $line;
        echo '<br/>';
    } else continue;
    $line_counter++;
}
fclose($fh);
