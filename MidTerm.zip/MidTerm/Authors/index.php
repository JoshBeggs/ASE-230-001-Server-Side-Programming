<?php
$fhAuthor=fopen('../Data/authors.csv','r');
$fhQuote=fopen('../Data/quotes.csv','r');
$index=0;

while($line=fgets($fhAuthor)) {
    if(strlen(trim($line))>0) echo '<h1><a href="detail.php?index='.$index.'">'.trim($line).'</a> (<a href="modify.php?index='.$index.'">modify</a>) (<a href="delete.php?index='.$index.'">delete</a>)</h1><br/>';

    $index++;
}
fclose($fhAuthor);
fclose($fhQuote);
?>