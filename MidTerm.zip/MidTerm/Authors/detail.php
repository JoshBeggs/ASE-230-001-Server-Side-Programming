<?php

$fh=fopen('../Data/authors.csv','r');
$line_counter=0;

while($line=fgets($fh)){
    if($line > 0) {
        //display the author
        echo $line;
        echo '<br/>';
        //if csv line has no data skip
    } else continue;
    $line_counter++;
}
fclose($fh);
