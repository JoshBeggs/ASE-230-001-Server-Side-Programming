<?php
if(!isset($_GET['index'])) {
    die('Please enter the author that you wish to modify');
}

if(count($_POST)>0) {
    //save the author's name into the file
    if(file_exists('../Data/Authors.csv')) {
        $line_counter=0;
        $new_file_content=''; //rod C
        $fh=fopen('../Data/authors.csv','r');
        while($line=fgets($fh)){
            if($line_counter==$_GET['index']) $new_file_content.=PHP_EOL;
            else $new_file_content.=$line;
            $line_counter++;
        }
        fclose($fh);
    
        file_put_contents('../Data/authors.csv', $new_file_content);
        echo 'You have successfully modified the author.';
    }
}
else {
    $author_name='';
    $line_counter=0;
    $fh=fopen('../data/authors.csv','r');
    while($line=fgets($fh)){
        if($line_counter==$_GET['index']) {
            //display the author
            $author_name=trim($line);
        }
        $line_counter++;
    }
    fclose($fh);

    ?>
    <form method="POST">
        Enter the author's name:<br/>
        <input type="text" name="name" /><br />
        <button type="submit">Modify authors</button>

    </form>

    <?php
}